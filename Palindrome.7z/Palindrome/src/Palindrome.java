public class Palindrome {
    public static void main(String[] args) {
        System.out.println(Palindrome.isPalindrome("Deleveled"));
    }

    public static boolean isPalindrome(String text){
        //Without array
       /* int stringLength = text.length();
        for(int i=0; i < stringLength; i++){
            if(Character.toLowerCase(text.charAt(i)) != Character.toLowerCase(text.charAt(stringLength -i -1)))
                return false;
        }
        return true;*/

       //With array
        char[] words = text.toLowerCase().toCharArray();
        int end = text.length();
        int mid = text.length()/2;

        for(int i = 0; i < mid; i++){
            if(words[i] != words[end -i-1])
                return false;
        }
        return true;
    }
}
